$("#ref-tab").click(function () {
  $(".slide-content-ref").slideToggle();
  $(".slide-content-ref").toggleClass('collapsed');
  $("#ref-tab a").toggleClass('active');
  $(".black-overlay").toggleClass('show');
  $(".popup-box").removeClass('expanded');
  $(".black-overlay1").removeClass('show');
  $(".black-overlay-center").removeClass('show');
});
$(".close-tab").click(function () {
  $(".slide-content-ref").slideToggle();
  $(".black-overlay").removeClass('show');
  $("#ref-tab a").removeClass('active');
  //$(".black-overlay-center").addClass('show');
});

/* Sidebar Menu */

$("#sidebar-menu-icon").click(function () {
  $(".slide-menu").toggleClass('expanded');
});

$("#sidebar-menu-close").click(function () {
  $(".slide-menu").toggleClass('expanded');
  $(".sub-menu-div").removeClass('expanded0');
  $(".sub-menu-div").removeClass('expanded');
  $(".sub-menu-div").removeClass('expanded2');
  $(".sub-menu-div").removeClass('expanded5');
  $(".slide-menu li.sub-menu ul").removeClass('menu-open');
  $("#submenu0").removeClass('active');
  $("#submenu1").removeClass('active');
  $("#submenu2").removeClass('active');
  $("#submenu5").removeClass('active');
});


/* Sidebar Menu - Submenu */

$("#submenu0").click(function () {
  $(".sub-menu-div").toggleClass('expanded');
  $(".slide-menu li#submenu0 ul").toggleClass('menu-open');
  $("#submenu0").toggleClass('active');
  $("#submenu1").removeClass('active');
  $("#submenu2").removeClass('active');
  $("#submenu5").removeClass('active');
  $(".slide-menu li#submenu1 ul").removeClass('menu-open');
  $(".slide-menu li#submenu2 ul").removeClass('menu-open');
  $(".slide-menu li#submenu5 ul").removeClass('menu-open');
  $(".sub-menu-div").removeClass('expanded1');
  $(".sub-menu-div").removeClass('expanded2');
  $(".sub-menu-div").removeClass('expanded5');
});

$("#submenu1").click(function () {
  $(".sub-menu-div").toggleClass('expanded');
  $(".slide-menu li#submenu1 ul").toggleClass('menu-open');
  $("#submenu1").toggleClass('active');
  $("#submenu2").removeClass('active');
  $("#submenu5").removeClass('active');
  $("#submenu0").removeClass('active');
  $(".slide-menu li#submenu0 ul").removeClass('menu-open');
  $(".slide-menu li#submenu2 ul").removeClass('menu-open');
  $(".slide-menu li#submenu5 ul").removeClass('menu-open');
  $(".sub-menu-div").removeClass('expanded0');
  $(".sub-menu-div").removeClass('expanded2');
  $(".sub-menu-div").removeClass('expanded5');
});

$("#submenu2").click(function () {
  $(".sub-menu-div").toggleClass('expanded2');
  $(".slide-menu li#submenu2 ul").toggleClass('menu-open');
  $("#submenu2").toggleClass('active');
  $("#submenu1").removeClass('active');
  $("#submenu5").removeClass('active');
  $("#submenu0").removeClass('active');
  $(".slide-menu li#submenu0 ul").removeClass('menu-open');
  $(".slide-menu li#submenu1 ul").removeClass('menu-open');
  $(".slide-menu li#submenu5 ul").removeClass('menu-open');
  $(".sub-menu-div").removeClass('expanded0');
  $(".sub-menu-div").removeClass('expanded');
  $(".sub-menu-div").removeClass('expanded5');
});

$("#submenu5").click(function () {
  $(".sub-menu-div").toggleClass('expanded5');
  $(".slide-menu li#submenu5 ul").toggleClass('menu-open');
  $("#submenu5").toggleClass('active');
  $("#submenu1").removeClass('active');
  $("#submenu2").removeClass('active');
  $("#submenu0").removeClass('active');
  $(".slide-menu li#submenu0 ul").removeClass('menu-open');
  $(".slide-menu li#submenu1 ul").removeClass('menu-open');
  $(".slide-menu li#submenu2 ul").removeClass('menu-open');
  $(".sub-menu-div").removeClass('expanded0');
  $(".sub-menu-div").removeClass('expanded');
  $(".sub-menu-div").removeClass('expanded2');
});

/* Bar graph 1*/

/* Conclusion Page  */

/* Popup 1 */

$("#popup1").click(function () {
  $(".popup-box1").addClass('expanded');
  $(".black-overlay1").toggleClass('show');
  $("#ref-tab").addClass('hide');
  $("#ref-tab1").addClass('show');
});

$(".popup-close1").click(function () {
  $(".popup-box1").removeClass('expanded');
  $(".black-overlay1").removeClass('show');
  $("#ref-tab").removeClass('hide');
  $("#ref-tab1").removeClass('show');
});

/* Popup 2 */

$("#popup2").click(function () {
  $(".popup-box2").addClass('expanded');
  $(".black-overlay1").toggleClass('show');
  $("#ref-tab").addClass('hide');
  $("#ref-tab2").addClass('show');
  $(".popup-box2").removeClass('collapsed');
  
});

$(".popup-close2").click(function () {
  $(".popup-box2").removeClass('expanded');
  $(".black-overlay1").removeClass('show');
  $("#ref-tab").removeClass('hide');
  $("#ref-tab2").removeClass('show');
});

/* Popup 3 */

$("#popup3").click(function () {
  $(".popup-box3").addClass('expanded');
  $(".black-overlay1").toggleClass('show');
  $("#ref-tab").addClass('hide');
  $("#ref-tab3").addClass('show');
  $(".popup-box3").removeClass('collapsed');
});

$(".popup-close3").click(function () {
  $(".popup-box3").removeClass('expanded');
  $(".black-overlay1").removeClass('show');
  $("#ref-tab").removeClass('hide');
  $("#ref-tab3").removeClass('show');
});

/* Popup 4 */

$("#popup4").click(function () {
  $(".popup-box4").addClass('expanded');
  $(".black-overlay1").toggleClass('show');
  $("#ref-tab").addClass('hide');
  $("#ref-tab4").addClass('show');
});

$(".popup-close4").click(function () {
  $(".popup-box4").removeClass('expanded');
  $(".black-overlay1").removeClass('show');
  $("#ref-tab").removeClass('hide');
  $("#ref-tab4").removeClass('show');
});

/* New Popup */
$("#ref-center-tab").click(function () {
  $("#ref-tab").addClass('hide');
  $("#ref-tab1").addClass('show');
  $(".black-overlay").removeClass('show');
});

$(".close-center-tab").click(function () {
  $("#ref-tab").removeClass('hide');
  $("#ref-tab1").removeClass('show');
  $("#ref-tab1 a").removeClass('active');
});

/* New Popup */
/*$("#popup-box-cardiac").click(function () {
  $("#ref-tab").addClass('hide');
  $("#ref-tab1").addClass('show');
  $(".black-overlay").removeClass('show');
});

$("#popup-box-cardiac-close").click(function () {
  $("#ref-tab").removeClass('hide');
  $("#ref-tab1").removeClass('show');
  $("#ref-tab1 a").removeClass('active');
  $(".slide-content-ref1").slideToggle();
});*/



/*  Ref tab 1 */

$("#ref-tab1").click(function () {
  $(".slide-content-ref1").slideToggle();
  $(".slide-content-ref1").toggleClass('collapsed');
  $("#ref-tab1 a").toggleClass('active');
  $(".black-overlay").toggleClass('show');
  $(".black-overlay1").removeClass('show');
  $(".black-overlay-center").removeClass('show');
});

$(".close-tab1").click(function () {
  $(".slide-content-ref1").slideToggle();
  $(".black-overlay").removeClass('show');
  $("#ref-tab1 a").removeClass('active');
  $(".black-overlay1").addClass('show');
  $(".black-overlay-center").addClass('show');
});

/*  Ref tab 2 */

$("#ref-tab2").click(function () {
  $(".slide-content-ref2").slideToggle();
  $(".slide-content-ref2").toggleClass('collapsed');
  $("#ref-tab2 a").toggleClass('active');
  $(".black-overlay").toggleClass('show');
  $(".black-overlay1").removeClass('show');
});

$(".close-tab2").click(function () {
  $(".slide-content-ref2").slideToggle();
  $(".black-overlay").removeClass('show');
  $("#ref-tab2").removeClass('active');
  $(".black-overlay1").addClass('show');
   $("#ref-tab2 a").removeClass('active');
});

/*  Ref tab 3 */

$("#ref-tab3").click(function () {
  $(".slide-content-ref3").slideToggle();
  $(".slide-content-ref3").addClass('collapsed');
  $("#ref-tab3 a").toggleClass('active');
  $(".black-overlay").toggleClass('show');
  $(".black-overlay1").removeClass('show');
});

$(".close-tab3").click(function () {
  $(".slide-content-ref3").slideToggle();
  $(".slide-content-ref3").removeClass('collapsed');
  $(".black-overlay").removeClass('show');
  $("#ref-tab3").removeClass('active');
  $(".black-overlay1").addClass('show');
  $("#ref-tab3 a").removeClass('active');
});

/*  Ref tab 4 */

$("#ref-tab4").click(function () {
  $(".slide-content-ref4").slideToggle();
  $(".slide-content-ref4").toggleClass('collapsed');
  $("#ref-tab4 a").toggleClass('active');
  $(".black-overlay").toggleClass('show');
  $(".black-overlay1").removeClass('show');
});

$(".close-tab4").click(function () {
  $(".slide-content-ref4").slideToggle();
  $(".black-overlay").removeClass('show');
  $("#ref-tab4").removeClass('active');
  $(".black-overlay1").addClass('show');
});

/* Ajax content load */
$("#study_overview").click(function () {
  $.ajax({
    url: "study-overview.txt",
    success: function (result) {
      $("#ajax_content").html(result);
    }
  });
});

$(document).ready(function () {
  $("#barbox1").delay(300).animate({
    top: "88%"
  });
  $("#barbox2").delay(900).animate({
    top: "80%"
  });
  $("#barbox3").delay(1200).animate({
    top: "76%"
  });
  $("#barbox4").delay(1500).animate({
    top: "54%"
  });
  $("#barbox5").delay(1800).animate({
    top: "58%"
  });
  $("#barbox6").delay(2100).animate({
    top: "38%"
  });
  $("#barbox7").delay(2400).animate({
    top: "25%"
  });
  $("#barbox8").delay(2700).animate({
    top: "12%"
  });
  $(".text1").delay(1000).show();
  $(".text2").delay(1000).show();
  $(".bars span").delay(1000).show();
  
});

/* graph - page efficacy-nt-proBNP-change */
$(document).ready(function () {
  $("#leftbar1").delay(300).animate({
    height: "36px"
  });
  $("#leftbar2").delay(300).animate({
    height: "82px"
  });
  $("#leftbar3").delay(300).animate({
    height: "46px"
  });
  $("#leftbar4").delay(300).animate({
    height: "86px"
  });
  $("#hook1").delay(800).animate({
    height: "15px",
	opacity: '1'
  });
  $("#hook2").delay(800).animate({
    height: "34px",
	opacity: '1'
  });
  $("#hook3").delay(800).animate({
	height: "20px",
	opacity: '1'
  });
  $("#hook4").delay(800).animate({
    height: "24px",
	opacity: '1'
  });
    $("#line1").delay(800).animate({
    height: "75px"
  });
  $("#line2").delay(800).animate({
    height: "10px"
  });
  $("#line3").delay(800).animate({
	height: "60px"
  });
  $("#line4").delay(800).animate({
    height: "12px"
  });
  $(".graph-188-info-line").delay(800).animate({
    width: "105px"
  });
});


$(document).ready(function () {
  $("#graph-50-1").delay(300).animate({
    height: "9px"
  });
  $("#graph-50-2").delay(300).animate({
    height: "6px"
  });
  $("#graph-50-3").delay(300).animate({
    height: "0px"
  });
  $("#graph-50-4").delay(300).animate({
    height: "9px"
  });
  $("#graph-50-5").delay(300).animate({
    height: "44px"
  });
  $("#graph-50-6").delay(300).animate({
    height: "13px"
  });
  $("#graph-50-7").delay(300).animate({
    height: "34px"
  });
  $("#graph-50-8").delay(300).animate({
    height: "16px"
  });
    $("#graph-50-9").delay(300).animate({
    height: "53px"
  });
  $("#graph-50-10").delay(300).animate({
    height: "34px"
  });
  $("#graph-50-11").delay(300).animate({
    height: "116px"
  });
  $("#graph-50-12").delay(300).animate({
    height: "61px"
  });
  $("#graph-50-13").delay(300).animate({
    height: "144px"
  });
  $("#graph-50-14").delay(300).animate({
    height: "106px"
  });
  $("#graph-50-15").delay(300).animate({
    height: "181px"
  });
  $("#graph-50-16").delay(300).animate({
    height: "201px"
  });
  $("#graph-50-17").delay(300).animate({
    height: "89px"
  });
  $("#graph-50-18").delay(300).animate({
    height: "160px"
  });
  $("#graph-50-19").delay(300).animate({
    height: "35px"
  });
  $("#graph-50-20").delay(300).animate({
    height: "75px"
  });
  $("#graph-50-21").delay(300).animate({
    height: "26px"
  });
  $("#graph-50-22").delay(300).animate({
    height: "52px"
  });
    $("#graph-50-23").delay(300).animate({
    height: "7px"
  });
  $("#graph-50-24").delay(300).animate({
    height: "21px"
  });
  
  $("#graph-50-25").delay(300).animate({
    height: "0px"
  });
  $("#graph-50-26").delay(300).animate({
    height: "0px"
  });
  $("#graph-50-27").delay(300).animate({
    height: "0px"
  });
  $("#graph-50-28").delay(300).animate({
    height: "2px"
  });

 
  $(".text1").delay(1000).show();
  $(".text2").delay(1000).show();
  $(".bars span").delay(1000).show();
  
});


$(document).ready(function () {
  $("#graph1-50-1").delay(300).animate({
    top: "97%"
  });
  $("#graph1-50-2").delay(300).animate({
    top: "98%"
  });
  $("#graph1-50-3").delay(300).animate({
    height: "0px"
  });
  $("#graph1-50-4").delay(300).animate({
    top: "97%"
  });
  $("#graph1-50-5").delay(300).animate({
    top: "83%"
  });
  $("#graph1-50-6").delay(300).animate({
    top: "96%"
  });
  $("#graph1-50-7").delay(300).animate({
    top: "86%"
  });
  $("#graph1-50-8").delay(300).animate({
    top: "94%"
  });
    $("#graph1-50-9").delay(300).animate({
    top: "81%"
  });
  $("#graph1-50-10").delay(300).animate({
    top: "86%"
  });
  $("#graph1-50-11").delay(300).animate({
    top: "59%"
  });
  $("#graph1-50-12").delay(300).animate({
    top: "78%"
  });
  $("#graph1-50-13").delay(300).animate({
    top: "50%"
  });
  $("#graph1-50-14").delay(300).animate({
    top: "61%"
  });
  $("#graph1-50-15").delay(300).animate({
    top: "37%"
  });
  $("#graph1-50-16").delay(300).animate({
    top: "31%"
  });
  $("#graph1-50-17").delay(300).animate({
    top: "72%"
  });
  $("#graph1-50-18").delay(300).animate({
    top: "44%"
  });
  $("#graph1-50-19").delay(300).animate({
    top: "90%"
  });
  $("#graph1-50-20").delay(300).animate({
    top: "73%"
  });
  $("#graph1-50-21").delay(300).animate({
    top: "92%"
  });
  $("#graph1-50-22").delay(300).animate({
    top: "82%"
  });
  $("#graph1-50-23").delay(300).animate({
    top: "98%"
  });
  $("#graph1-50-24").delay(300).animate({
    top: "92%"
  });
  
  $("#graph1-50-25").delay(300).animate({
    height: "0px"
  });
  $("#graph1-50-26").delay(300).animate({
    height: "0px"
  });
  $("#graph1-50-27").delay(300).animate({
    height: "0px"
  });
  $("#graph1-50-28").delay(300).animate({
    top: "98%"
  });

 
  $(".text1").delay(1000).show();
  $(".text2").delay(1000).show();
  $(".bars span").delay(1000).show();
  
});

/*JS added by Annamalai*/
/*Popup*/
function deselect(e) {
  $('.pop').slideFadeToggle(function() {
    e.removeClass('selected');
  });    
}

$(function() {
  $('#popup-box-cardiac').on('click', function() {
    if($(this).hasClass('selected')) {
      deselect($(this));               
    } else {
      $(this).addClass('selected');
      $('.pop').slideFadeToggle();
	  $('.black-overlay1').toggleClass('show');
    }
    return false;
  });

  $('.popup-close').on('click', function() {
    deselect($('#popup-box-cardiac'));
	$('.black-overlay1').removeClass('show');
	$('.pop').css("display", "none");
    return false;
  });
});

$.fn.slideFadeToggle = function(easing, callback) {
  return this.animate({ opacity: 'toggle', height: 'toggle' }, 'fast', easing, callback);
};

$(function() {
  $('#popup-box-biopsy').on('click', function() {
    if($(this).hasClass('selected')) {
      deselect($(this));               
    } else {
      $(this).addClass('selected');
      $('.pop1').slideFadeToggle();
	  $('.black-overlay1').toggleClass('show');
    }
    return false;
  });

  $('.popup-close1').on('click', function() {
    deselect($('#popup-box-biopsy'));
	$('.black-overlay1').removeClass('show');
	$('.pop1').css("display", "none");
	$('.pop').css("display", "none");
    return false;
  });
});

$.fn.slideFadeToggle = function(easing, callback) {
  return this.animate({ opacity: 'toggle', height: 'toggle' }, 'fast', easing, callback);
};

$(function() {
  $('#popup-box-nyha').on('click', function() {
    if($(this).hasClass('selected')) {
      deselect($(this));               
    } else {
      $(this).addClass('selected');
      $('.pop2').slideFadeToggle();
	  $('.black-overlay1').toggleClass('show');
    }
    return false;
  });

  $('.popup-close2').on('click', function() {
    deselect($('#popup-box-nyha'));
	$('.black-overlay1').removeClass('show');
	$('.pop2').css("display", "none");
	$('.pop').css("display", "none");
    return false;
  });
});

$.fn.slideFadeToggle = function(easing, callback) {
  return this.animate({ opacity: 'toggle', height: 'toggle' }, 'fast', easing, callback);
};

/*left right arrow funtion*/
$(document).ready(function(){
    $(".divs .cls").each(function(e) {
        if (e != 0)
            $(this).hide();
    });

    $("#next").click(function(){
        if ($(".divs .cls:visible").next().length != 0)
            $(".divs .cls:visible").next().show().prev().hide();
        else {
            $(".divs .cls:visible").hide();
            $(".divs .cls:first").show();
        }
        return false;
    });

    $("#prev").click(function(){
        if ($(".divs .cls:visible").prev().length != 0)
            $(".divs .cls:visible").prev().show().next().hide();
        else {
            $(".divs .cls:visible").hide();
            $(".divs .cls:last").show();
        }
        return false;
    });
});

/* JS added by Annamalai */



/* js added by Jeeru */

$("#ref-center-tab-single").click(function () {
  $(".center-popup-single").slideToggle();
  $(".center-popup-single").toggleClass('collapsed');
  $("#ref-center-tab-single").toggleClass('active');
  $(".black-overlay-center").toggleClass('show');
});
$(".close-center-single-tab").click(function () {
  $(".center-popup-single").slideToggle();
  $(".black-overlay-center").removeClass('show');
  $("#ref-center-tab-single").removeClass('active');
});

$("#ref-center-tab-single-two").click(function () {
  $(".center-popup-single-two").slideToggle();
  $(".center-popup-single-two").toggleClass('collapsed');
  $("#ref-center-tab-single-two").toggleClass('active');
  $(".black-overlay-center").toggleClass('show');
});
$(".close-center-single-tab-two").click(function () {
  $(".center-popup-single-two").slideToggle();
  $(".black-overlay-center").removeClass('show');
  $("#ref-center-tab-single-two").removeClass('active');
});

$("#ref-center-tab").click(function(){
	$(".center-popup").slideToggle();
	$(".center-popup").toggleClass('collapsed');
	$("#ref-center-tab").toggleClass('active');
	$(".black-overlay-center").toggleClass('show');
});
$(".close-center-tab-double").click(function(){
	$(".center-popup").slideToggle();
	$(".black-overlay-center").removeClass('show');
	$("#ref-center-tab").removeClass('active');
});

$("#ref-center-tab-double").click(function(){
	$(".center-popup-double").slideToggle();
	$(".center-popup-double").toggleClass('collapsed');
	$("#ref-center-tab-double").toggleClass('active');
	$(".black-overlay-center").toggleClass('show');
	$(".popup-box2").removeClass('expanded');
	$(".popup-box2").addClass('collapsed');
});
$(".close-center-tab").click(function(){
	$(".center-popup-double").slideToggle();
	$(".black-overlay-center").removeClass('show');
	$("#ref-center-tab-double").removeClass('active');
});


$("#ref-center-tab-two").click(function(){
	$(".center-popup-two").slideToggle();
	$(".center-popup-two").toggleClass('collapsed');
	$("#ref-center-tab-two").toggleClass('active');
	$(".black-overlay-center").toggleClass('show');
});
$(".close-center-tab-double-two").click(function(){
	$(".center-popup-two").slideToggle();
	$(".black-overlay-center").removeClass('show');
	$("#ref-center-tab-two").removeClass('active');
});

$("#ref-center-tab-two-double").click(function(){
	$(".center-popup-double-two").slideToggle();
	$(".center-popup-double-two").toggleClass('collapsed');
	$("#ref-center-tab-two-double").toggleClass('active');
	$(".black-overlay-center").toggleClass('show');
	$(".popup-box3").removeClass('expanded');
	$(".popup-box3").addClass('collapsed');
});
$(".close-center-tab-two").click(function(){
	$(".center-popup-double-two").slideToggle();
	$(".black-overlay-center").removeClass('show');
	$("#ref-center-tab-two-double").removeClass('active');
});


$('#aasp-next').click(function() {
  $('.current').removeClass('current').hide()
    .next().show().addClass('current');

  if ($('.current').hasClass('last')) {
    $('#aasp-next').css('display', 'none');
  }
  $('#aasp-prev').css('display', 'block');
});

$('#aasp-prev').click(function() {
  $('.current').removeClass('current').hide()
    .prev().show().addClass('current');

  
  if ($('.current').hasClass('first')) {
    $('#aasp-prev').css('display', 'none');
  }
  $('#aasp-next').css('display', 'block');
});


$(document).ready(function () {
  $(".ntprobnp-month #ntprobnp1").delay(300).animate({
    height: "50.7%"
  });
  $(".ntprobnp-month #ntprobnp2").delay(300).animate({
    height: "36.1%"
  });
  $(".ntprobnp-month #ntprobnp3").delay(300).animate({
    height: "23.6%"
  });
  $(".ntprobnp-month #ntprobnp4").delay(300).animate({
    height: "45.5%"
  });
  $(".ntprobnp-month #ntprobnp5").delay(300).animate({
    height: "23.3%"
  });
  $(".ntprobnp-month #ntprobnp6").delay(300).animate({
    height: "12.5%"
  });
  $(".text1").delay(1000).show();
  $(".text2").delay(1000).show();
  $(".bars span").delay(1000).show();
  
});

$(document).ready(function () {
  $(".ntprobnp-month #ntprobnp-31").delay(300).animate({
    height: "82.7%"
  });
  $(".ntprobnp-month #ntprobnp-32").delay(300).animate({
    height: "65.9%"
  });
  $(".ntprobnp-month #ntprobnp-33").delay(300).animate({
    height: "63.5%"
  });
  $(".ntprobnp-month #ntprobnp-34").delay(300).animate({
    height: "77.8%"
  });
  $(".ntprobnp-month #ntprobnp-35").delay(300).animate({
    height: "71.1%"
  });
  $(".ntprobnp-month #ntprobnp-36").delay(300).animate({
    height: "32.7%"
  });
  $(".text1").delay(1000).show();
  $(".text2").delay(1000).show();
  $(".bars span").delay(1000).show();
  
});

$(document).ready(function () {
  $(".ntprobnp-month #ntprobnp-331").delay(300).animate({
    height: "33%"
  });
  $(".ntprobnp-month #ntprobnp-332").delay(300).animate({
    height: "24%"
  });
  $(".ntprobnp-month #ntprobnp-333").delay(300).animate({
    height: "8%"
  });
  $(".ntprobnp-month #ntprobnp-334").delay(300).animate({
    height: "45%"
  });
  $(".ntprobnp-month #ntprobnp-335").delay(300).animate({
    height: "14%"
  });
  $(".ntprobnp-month #ntprobnp-336").delay(300).animate({
    height: "0%"
  });
  $(".text1").delay(1000).show();
  $(".text2").delay(1000).show();
  $(".bars span").delay(1000).show();
  
});

$(document).ready(function () {
  $(".primary_analysis-left #primary1").delay(300).animate({
    height: "71%"
  });
  $(".primary_analysis-left #primary2").delay(300).animate({
    height: "57%"
  });
  $(".text1").delay(1000).show();
  $(".text2").delay(1000).show();
  $(".bars span").delay(1000).show();
  
});
$(document).ready(function () {
  $(".primary_analysis-right #primary1").delay(300).animate({
    height: "30%"
  });
  $(".primary_analysis-right #primary2").delay(300).animate({
    height: "46%"
  });
  $(".text1").delay(1000).show();
  $(".text2").delay(1000).show();
  $(".bars span").delay(1000).show();
  
});
$(document).ready(function () {
  $(".frequency-1st-bottom #frequency1").delay(300).animate({
    height: "45%"
  });
  $(".frequency-1st-bottom #frequency2").delay(300).animate({
    height: "60%"
  });
  $(".frequency-1st-bottom #barbox-b1").delay(300).animate({
    height: "30%"
  });
  $(".frequency-1st-bottom #barbox-b1 .barbox-text").delay(300).animate({
    height: "40px"
  });
  $(".text1").delay(1000).show();
  $(".text2").delay(1000).show();
  $(".bars span").delay(1000).show();
  
});
$(document).ready(function () {
$('.line-graph-animation').animate({width: "100%"},1000);
$('.height-graph-animation').animate({height: "100%"},1000); 
});

$(document).ready(function(){
  $(".next-animation").click(function(){
    $(".line-graph-animation-next").animate({width: "100%"},1000);
  });
  $(".next-height-animation").click(function(){
    $(".height-graph-animation-next").animate({height: "100%"},1000);
  });
});


setInterval(function(){
if(jQuery('#parentScrollDiv > div').length < 2){
    jQuery('#parentScrollDiv').addClass('scroll-none');
    }
else{
    jQuery('#parentScrollDiv').removeClass('scroll-none');
    }
});


$(document).ready(function () {
  $(".col-a #kccq1").delay(300).animate({
    width: "50%"
  });
  $(".col-a #kccq2").delay(300).animate({
    width: "6%"
  });
  $(".col-b #kccq1").delay(300).animate({
    width: "55%"
  });
  $(".col-b #kccq2").delay(300).animate({
    width: "10%"
  });
  $(".col-c #kccq1").delay(300).animate({
    width: "75%"
  });
  $(".col-c #kccq2").delay(300).animate({
    width: "15%"
  });
  $(".col-d #kccq1").delay(300).animate({
    width: "70%"
  });
  $(".col-d #kccq2").delay(300).animate({
    width: "20%"
  });
  $(".text1").delay(1000).show();
  $(".text2").delay(1000).show();
  $(".bars span").delay(1000).show();
  
});

/* js added by Jeeru */

