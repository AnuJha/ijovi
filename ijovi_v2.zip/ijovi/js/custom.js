
  $("#banner h1").mouseover(function () {
    $("#popup").addClass('expanded');
  });

  $("#btn-close").click(function () {
    $("#popup").removeClass('expanded');
  });
  
  $("#popup").mouseover(function () {
    $("#popup").addClass('expanded');
  });
  
  $("#popup").mouseout(function () {
    $("#popup").removeClass('expanded');
  });

  $("#tab1").click(function () {
    $("#ex1").toggleClass('expanded');
	$("#ex2").removeClass('expanded');
	$("#ex3").removeClass('expanded');
	$("#ex4").removeClass('expanded');
	
	$("#tab1").toggleClass('active');
	$("#tab2").removeClass('active');
	$("#tab3").removeClass('active');
	$("#tab4").removeClass('active');
  });
  
  $("#tab2").click(function () {
    $("#ex2").toggleClass('expanded');
	$("#ex1").removeClass('expanded');
	$("#ex3").removeClass('expanded');
	$("#ex4").removeClass('expanded');
	
	$("#tab2").toggleClass('active');
	$("#tab1").removeClass('active');
	$("#tab3").removeClass('active');
	$("#tab4").removeClass('active');
  });
  
  $("#tab3").click(function () {
    $("#ex3").toggleClass('expanded');
	$("#ex1").removeClass('expanded');
	$("#ex2").removeClass('expanded');
	$("#ex4").removeClass('expanded');
	
	$("#tab3").toggleClass('active');
	$("#tab1").removeClass('active');
	$("#tab2").removeClass('active');
	$("#tab4").removeClass('active');
  });
  
  $("#tab4").click(function () {
    $("#ex4").toggleClass('expanded');
	$("#ex1").removeClass('expanded');
	$("#ex2").removeClass('expanded');
	$("#ex3").removeClass('expanded');
	
	$("#tab4").toggleClass('active');
	$("#tab1").removeClass('active');
	$("#tab2").removeClass('active');
	$("#tab3").removeClass('active');
  });
